// req-08
const { Router } = require('express');
const validateJWT = require('../auth/validateJWT');
const createCategory = require('../controllers/createCategory');
const getCategories = require('../controllers/getCategories'); // req-09

const categoryRoute = Router();

categoryRoute.post('/categories', validateJWT, createCategory);
categoryRoute.get('/categories', validateJWT, getCategories); // req-09

module.exports = categoryRoute;