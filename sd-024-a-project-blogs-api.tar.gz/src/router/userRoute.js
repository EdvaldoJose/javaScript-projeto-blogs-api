// req-03
const { Router } = require('express');
const userController = require('../controllers/getUsers');
const validateJWT = require('../auth/validateJWT');
const login = require('../controllers/login');
const validateBody = require('../middleware/loginValidation');
const createUser = require('../controllers/createUser'); // req-04
const validateUser = require('../middleware/userValidation'); // req-04
const deleteUser = require('../controllers/deleteUser'); // req-17

const userRoute = Router();

userRoute.get('/user', validateJWT, userController.getAllUsers);
userRoute.get('/user/:id', validateJWT, userController.getUserById);
userRoute.post('/login', validateBody, login);
userRoute.post('/user', validateUser, createUser); // req-04
userRoute.delete('/user/me', validateJWT, deleteUser); // req-17

module.exports = userRoute;