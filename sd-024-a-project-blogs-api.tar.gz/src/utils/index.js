module.exports = {
  'string.empty': 400,
  'string required': 400,
  'any.required': 400,
  'any.invalid': 400,
  'string.min': 400,
  'string.email': 400,
  'string.title': 400,
  'string.content': 400,
  HTTP_OK: 200,
  NOT_FOUND: 404,
};