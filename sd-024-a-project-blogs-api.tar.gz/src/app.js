const express = require('express');
// req-03
const userRoute = require('./routes/userRoute');
// req-08
const categoryRoute = require('./routes/categoryRoute');
// req-13
const postsRoute = require('./routes/postsRoutes');

const app = express();

app.use(express.json());

// req-03
app.use(userRoute);
// req-08
app.use(categoryRoute);
// req-13
app.use(postsRoute);

// É importante exportar a constante `app`,
// para que possa ser utilizada pelo arquivo `src/server.js`
module.exports = app;
