module.exports = {
  rootDir: './__tests__',
  testSequencer: './assets/sequencer.js',
  testRegex: './*\\.test\\.js$',
  testTimeout: 180000,
};
